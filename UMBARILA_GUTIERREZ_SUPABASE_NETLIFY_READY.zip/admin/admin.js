const supabaseUrl = "https://TU_SUPABASE_URL.supabase.co";
const supabaseKey = "TU_SUPABASE_PUBLIC_KEY";
const supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);

async function createPost() {
const title = document.getElementById("title").value;
const content = document.getElementById("content").value;
const image = document.getElementById("image").value;

await supabaseClient.from("news").insert([{title, content, image}]);
alert("Publicado correctamente");
}
