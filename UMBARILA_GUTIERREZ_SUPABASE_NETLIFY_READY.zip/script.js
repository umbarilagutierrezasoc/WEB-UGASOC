const supabaseUrl = "https://TU_SUPABASE_URL.supabase.co";
const supabaseKey = "TU_SUPABASE_PUBLIC_KEY";
const supabaseClient = supabase.createClient(supabaseUrl, supabaseKey);

async function loadNews(){
const {data} = await supabaseClient.from("news").select("*").order("id",{ascending:false});
const container = document.getElementById("news-container");
if(data){
container.innerHTML = data.map(n=>`
<div class="card">
<h3>${n.title}</h3>
<img src="${n.image}" style="width:100%">
<p>${n.content}</p>
</div>`).join("");
}
}

loadNews();

function rate(num){
alert("Gracias por tu calificación de "+num+" estrellas");
}
